package pk.lm.pasir_lepa_martyna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasirLepaMartynaApplicationTests {

    @Test
    void contextLoads() {
    }

}
