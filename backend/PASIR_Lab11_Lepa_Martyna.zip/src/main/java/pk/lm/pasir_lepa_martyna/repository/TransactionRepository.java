package pk.lm.pasir_lepa_martyna.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pk.lm.pasir_lepa_martyna.model.Transaction;
import pk.lm.pasir_lepa_martyna.model.User;

import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findAllByUser(User user);
}