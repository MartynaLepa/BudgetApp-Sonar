package pk.lm.pasir_lepa_martyna.security;

import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

@Component
public class JwtUtil {

    // Generates a strong key for signing tokens
    private final SecretKey key = Jwts.SIG.HS512.key().build();

    public String generateToken(String email) {
        long expirationMs = 3600000; // 1 hour
        return Jwts.builder()
                .subject(email)                                              // 'sub': who owns the token
                .issuedAt(new Date())                                        // 'iat': when it was issued
                .expiration(new Date(System.currentTimeMillis() + expirationMs)) // 'exp': when it expires
                .signWith(key)                                               // sign with key
                .compact();                                                  // finish building
    }

    public String extractUsername(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .getSubject();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parser().verifyWith(key).build().parseSignedClaims(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}